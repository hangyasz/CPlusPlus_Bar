//
// Created by Zoli on 2024. 05. 02..
//

#ifndef TESZTEK_H
#define TESZTEK_H

#include "Ital.h"
#include "koktle.h"
#include "memtrace.h"
#include <iostream>


#endif //TESZTEK_H
