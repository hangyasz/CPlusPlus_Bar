//
// Created by Zoli on 2024. 05. 17..
//

#include "fugvenyek.hpp"
#include <iostream>
#include "string5.h"
#include "memtrace.h"
#include "koktle.h"
#include "Ital.h"



