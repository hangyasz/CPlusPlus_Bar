//
// Created by Zoli on 2024. 04. 17..
//

#ifndef BEVITEL_KEZEZ_H
#define BEVITEL_KEZEZ_H

#include <iostream>

void bufer_torles(); //bemeneti puffer torlese
char *hoszusor_olvas(); //hoszusoros beolvasása sztendert bementröl
int int_beolvas(); //egész szám beolvasása standard bemenetről
float float_beolvas(); //lebegőpontos szám beolvasása standard bemenetről
unsigned int unsigned_int_beolvas(); //pozitív egész szám beolvasása standard bemenetről
size_t size_beolvas(); //pozitív egész szám beolvasása standard bemenetről
void vait(); //várakozás a billentyű lenyomására



#endif //BEVITEL_KEZEZ_H
