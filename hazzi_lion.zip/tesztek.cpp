//
// Created by Zoli on 2024. 05. 02..
//

#include "tesztek.h"
#include "Ital.h"
#include "koktle.h"
#include "gtest_lite.h"
#include <iostream>

#include "memtrace.h"



