//
// Created by Zoli on 2024. 04. 17..
//

#include "bevitel_kezel.h"
#include <iostream>
#include <cstring>
#include <limits>


void bufer_torles() {
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

char* hoszusor_olvas() {
    size_t capacity = 25;  // Kezdeti kapacitás
    char* s = new char[capacity];
    size_t length = 0;  // A tömb jelenlegi hossza
    std::cin.clear();
    char c;
    std::cin.get(c);
    if(c!='\n'){
        s[length++]=c;
    }
    while (std::cin.get(c) && c != '\n') {
        if (length + 1 == capacity) {  // Ha betelt a tömb
            capacity *= 2;  // Duplázzuk a kapacitást
            char* temp = new char[capacity];
            strcpy(temp,s); // Másoljuk az eddigi karaktereket
            delete[] s;
            s = temp;
        }
        s[length++] = c;
    }
    if(length==0){
        delete[] s;
        return nullptr;
    }
    s[length] = '\0';  // Lezárjuk a stringet
    return s;
}


int int_beolvas() {
    int olvas;
    while(!(std::cin >> olvas)){
        bufer_torles();
        std::cout << "Hibas bemenet. Kerlek, adj meg egy szamot!" << std::endl;
    }
    return olvas;
}

float float_beolvas() {
    float olvas;
    while(!(std::cin >> olvas)){
        bufer_torles();
        std::cout << "Hibas bemenet. Kerlek, adj meg egy tizedes szamot!" << std::endl;
    }
    return olvas;
}

unsigned int unsigned_int_beolvas() {
    unsigned int olvas;
    while(!(std::cin >> olvas)){
        bufer_torles();
        std::cout << "Hibas bemenet. Kerlek, adj meg egy elojel szamot!" << std::endl;
    }
    return olvas;
}

size_t size_beolvas() {
    size_t olvas;
    while(!(std::cin >> olvas)){
        bufer_torles();
        std::cout << "Hibas bemenet. Kerlek, adj meg egy szamot!" << std::endl;
    }
    return olvas;
}

void vait() {
    std::cout << "Nyomjon meg az enetert a folytatashoz...";
    bufer_torles();
    std::getchar();
}




